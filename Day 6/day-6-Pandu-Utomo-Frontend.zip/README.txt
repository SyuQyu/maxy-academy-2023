1.Jalankan file index.html
2.Jalankan json-server dengan cara json-server db.json 
3.website dapat melakukan save ke favorite & hapus dari favorite dengan menggunakan json-server
4.website melakukan fetch api 3rd party dari tvmaze