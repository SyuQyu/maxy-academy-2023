saya membuat login register dan logout menggunakan firebase
dan get data notes juga menggunakan firebase
selanjutnya untuk notifcation saya pakai setelah logout akan muncul
camera dan lokasi juga sudah saya taruh di dalam situ menggunakan link