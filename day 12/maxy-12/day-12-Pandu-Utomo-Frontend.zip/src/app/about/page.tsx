export default function About() {
    return (
        <div className='flex flex-col w-full'>
            <h1>About Us Page</h1>
        </div>
    )
}